package com.internousdev.template.action;

import com.opensymphony.xwork2.ActionSupport;

public class UserCreateAction extends ActionSupport {

	/**
	 * ユーザー情報登録画面遷移処理
	 */
	public String execute() {
		return SUCCESS;
	}
}
