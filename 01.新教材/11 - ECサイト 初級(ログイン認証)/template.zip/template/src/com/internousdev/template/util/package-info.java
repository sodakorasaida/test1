/**
 * 
 */
/**
 * @author internous
 *
 */
package com.internousdev.template.util;