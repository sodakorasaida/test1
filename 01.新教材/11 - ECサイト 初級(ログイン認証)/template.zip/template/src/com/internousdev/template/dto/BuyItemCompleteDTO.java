package com.internousdev.template.dto;

public class BuyItemCompleteDTO {

}
